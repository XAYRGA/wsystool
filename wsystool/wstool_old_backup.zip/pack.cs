﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Be.IO;
using libJAudio;
using Newtonsoft.Json;

namespace wsysbuilder
{
    public static class pack
    {

        public static Stream[] awHandles;

        public static string createProjectFolder(string output_file)
        {
            var path = Path.GetFullPath(output_file);
            var dir = Path.GetDirectoryName(path);
            var fname = Path.GetFileName(output_file);
            Directory.CreateDirectory($"{dir}/aw_{fname}");
            return $"{dir}/aw_{fname}";
        }

        public static byte[] transform_pcm16_mono_adpcm(PCM16WAV WaveData, out int adjustedSampleCount)
        {
            int last = 0;
            int penult = 0;
            return transform_pcm16_mono_adpcm(WaveData, out adjustedSampleCount, 0, out last,out penult);
        }
        public static byte[] transform_pcm16_mono_adpcm(PCM16WAV WaveData, out int adjustedSampleCount, int loopRetSample , out int last, out int penult)
        {
            //adpcm_data = new byte[((WaveData.sampleCount / 9) * 16)];

          
            int frameCount = (WaveData.sampleCount + 16 - 1) / 16;
            adjustedSampleCount = frameCount * 16; // now that we have a properly calculated frame count, we know the amount of samples that realistically fit into that buffer. 
            var frameBufferSize = frameCount * 9; // and we know the amount of bytes that the buffer will take.
            var adjustedFrameBufferSize = frameBufferSize; //+ (frameBufferSize % 32); // pads buffer to 32 bytes. 
            byte[] adpcm_data = new byte[adjustedFrameBufferSize + 18]; // 9 bytes per 16 samples 

            last = 0;
            penult = 0;
            //Console.WriteLine($"\n\n\n{WaveData.sampleCount} samples\n{frameCount} frames.\n{frameBufferSize} bytes\n{adjustedFrameBufferSize} padded bytes. ");
            var adp_f_pos = 0; // ADPCM position

            var lastSample = 0; 
            var penultimate = 0; 

            var wavFP = WaveData.buffer;
            // transform one frame at a time
            for (int ix = 0; ix < frameCount; ix++)
            {
                short[] wavIn = new short[16];
                byte[] adpcmOut = new byte[9];
                for (int k = 0; k < 16; k++)
                {
                    if ( ((ix*16) + k) >= WaveData.sampleCount)
                        continue; // skip if we're out of samplebuffer, continue to build last frame
                    if ((ix * 16) + k == loopRetSample)
                    {
                        last = lastSample;
                        penult = penultimate;
                    }

                    wavIn[k] = wavFP[ (ix*16) + k];
                }
                // build ADPCM frame
                bananapeel.Pcm16toAdpcm4(wavIn, adpcmOut, ref lastSample, ref penultimate); // convert PCM16 -> ADPCM4
                for (int k = 0; k < 9; k++)
                {
                    adpcm_data[adp_f_pos] = adpcmOut[k]; // dump into ADPCM buffer.
                    adp_f_pos++; // increment ADPCM byte
                }
            }
            return adpcm_data;
        }

        public static unsafe void pack_do(string projFolder, string outfile)
        {
            cmdarg.assert(!Directory.Exists(projFolder), "Project folder '{0}' could not be found", projFolder);
            cmdarg.assert(!File.Exists($"{projFolder}/manifest.json"), "Could not find 'manifest.json'") ;
            string awOutput = null;
            try
            {
                awOutput = createProjectFolder(outfile);
            } catch (Exception E) { cmdarg.assert($"Could not create export folder. ({E.Message})"); }

            var sceneCount = 0;
            var wsProject = JsonConvert.DeserializeObject<wsysProject>(File.ReadAllText($"{projFolder}/manifest.json"));
            var waveTable = JsonConvert.DeserializeObject<Dictionary<int,JWaveDescriptor>>(File.ReadAllText($"{projFolder}/{wsProject.waveTable}"));
            //var waveIDPtr = JsonConvert.DeserializeObject<Dictionary<int, int>>(File.ReadAllText($"{projFolder}/{wsProject.waveTable}"));
            sceneCount = wsProject.sceneOrder.Length;
            
            var wsysFile = File.OpenWrite($"{projFolder}/out.wsy");
            var wsysWriter = new BeBinaryWriter(wsysFile);


            var sceneProjects = new minifiedScene[wsProject.sceneOrder.Length];

            for (int sci = 0; sci < wsProject.sceneOrder.Length; sci++)
            {
                cmdarg.assert(!File.Exists($"{projFolder}/{wsProject.sceneOrder[sci]}"), $"Cannot find scene file '{projFolder}/{wsProject.sceneOrder[sci]}' from manifest.");
                var scnData = JsonConvert.DeserializeObject<minifiedScene>(File.ReadAllText($"{projFolder}/{wsProject.sceneOrder[sci]}"));
                sceneProjects[sci] = scnData;
            }


            wsysWriter.Write(0x57535953); // WSYS;
            wsysWriter.Write(0); // Temporary size;
            wsysWriter.Write(wsProject.id); // Global ID
            wsysWriter.Write(0); //0? 
            wsysWriter.Write(0); // Offset to WINF
            wsysWriter.Write(0); // Offset to WBCT
            wsysWriter.Write(0L); // 8 bytes padding
            // Start Writing WAVE DATA
            var totalWaves = 0;
            Dictionary<int, Dictionary<int, JWaveDescriptor>> sceneLayout = new Dictionary<int, Dictionary<int, JWaveDescriptor>>();
            #region aw build
            for (int sci=0; sci < wsProject.sceneOrder.Length; sci++)
            {
                var scnData = sceneProjects[sci];
                sceneLayout[sci] = new Dictionary<int, JWaveDescriptor>();
                var awOutHnd = File.Open($"{awOutput}/{scnData.awfile}", FileMode.OpenOrCreate, FileAccess.ReadWrite);
                var awOutWt = new BeBinaryWriter(awOutHnd);
                var total_aw_offset = 0;
                totalWaves += scnData.waves.Length;

                Console.WriteLine(totalWaves);
                for (int wvi = 0; wvi < scnData.waves.Length; wvi++)
                {
                    var miniIndex = scnData.waves[wvi];
                    var wData = waveTable[miniIndex];
             
                    int last = wData.last;
                    int penult = wData.penult;

                    wData.mOffset = (int)wsysWriter.BaseStream.Position;
                    wsysWriter.Write((byte)0xCC);
                    wsysWriter.Write((byte)wData.format);
                    wsysWriter.Write((byte)wData.key);
                    wsysWriter.Write((byte)0);

                    byte[] adpcm_data;

                    var cWaveFile = $"{projFolder}/custom/{miniIndex}.wav";
                    if (File.Exists(cWaveFile))
                    {
                        var strm = File.OpenRead(cWaveFile);
                        var strmInt = new BinaryReader(strm);

                        var WaveData = PCM16WAV.readStream(strmInt);
                        if (WaveData == null)
                            cmdarg.assert($"ABORT: '{cWaveFile} has invalid format.");

                        cmdarg.assert(WaveData.sampleRate > 48000, $"ABORT: '{cWaveFile}' has samplerate {WaveData.sampleRate}hz (Max: 32000hz)");
                        cmdarg.assert(WaveData.channels > 1, $"ABORT: '{cWaveFile}' has too many channels {WaveData.channels}chn (Max: 1)");
                        // Console.WriteLine($"\n\t*** Packing custom wave {cWaveFile}");
                        int samplesCount = 0;

                        if (WaveData.sampler.loops != null && WaveData.sampler.loops.Length > 0)
                        {
                            wData.loop = true;
                            wData.loop_start = WaveData.sampler.loops[0].dwStart;
                            wData.loop_end = WaveData.sampler.loops[0].dwEnd;
                        } else
                        {
 
                        }


                        var byteInfo = transform_pcm16_mono_adpcm(WaveData, out samplesCount, wData.loop_start,out last, out penult);
                        adpcm_data = byteInfo;
                        wData.sampleRate = WaveData.sampleRate;
                        wData.sampleCount = samplesCount; // __wow__
                    }
                    else
                    {
                        var reffile = $"{projFolder}/ref/{miniIndex}.adp";
                        cmdarg.assert(!File.Exists(reffile), "ABORT: Could not find reference file: {0}", reffile);
                        adpcm_data = File.ReadAllBytes(reffile);
                    }


                    wsysWriter.Write((float)wData.sampleRate);
                    wsysWriter.Write(total_aw_offset);
                    wsysWriter.Write(adpcm_data.Length); // SHOULD spit out exact frame length. holy FUCK.
                    wsysWriter.Write(wData.loop ? 0xFFFFFFFF : 0x00000000);
                    wsysWriter.Write(wData.loop_start);
                    wsysWriter.Write(wData.loop_end);
                    wsysWriter.Write(wData.sampleCount);
                    wsysWriter.Write((short)last);
                    wsysWriter.Write((short)penult);
                    wsysWriter.Write(0);
                    wsysWriter.Write(0xCCCCCCCC);
                    wsysWriter.Flush();
        
                    // write buffer to AW
                    awOutHnd.Write(adpcm_data, 0, adpcm_data.Length);
                    //util.padTo(awOutWt, 32); // pad to 32 bytes go to hell
                    awOutHnd.Flush();
                    total_aw_offset = (int)awOutHnd.Position; // write the out position because that's what we've padded to

                    if (total_aw_offset % 9 != 0)
                    {
                        var oc = Console.ForegroundColor;
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine($"ALERT: ADPCM SAMPLES NOT ALIGNED TO 9 Dividend remainder: ({total_aw_offset % 9})");
                        total_aw_offset = (int)awOutHnd.Position;
                        Console.ForegroundColor = oc;
                    }
                    sceneLayout[sci][wvi] = wData;
                    // You can't see me
                    // behind the screen
                    util.consoleProgress($"\t->Rebuild ({scnData.awfile})", wvi, scnData.waves.Length - 1, true);
                }
                Console.WriteLine();
            }
            #endregion


            int[] wgPointers = new int[sceneProjects.Length];
            int[] scnePointers = new int[sceneProjects.Length];
            for (int sci = 0; sci < sceneProjects.Length; sci++)
            {
                util.padTo(wsysWriter, 32);
                var scnData = sceneProjects[sci];
                wgPointers[sci] = (int)wsysWriter.BaseStream.Position;
               
                var name = Encoding.ASCII.GetBytes(scnData.awfile);
                wsysWriter.BaseStream.Write(name,0,name.Length);
                for (int i = 0; i < 0x70 - name.Length; i++)
                    wsysWriter.Write((byte)0);
                wsysWriter.Write(scnData.waves.Length);
                var scnLt = sceneLayout[sci];
                for (int i = 0; i < scnData.waves.Length;i++)
                {
                    wsysWriter.Write(scnLt[i].mOffset);
                }
            }
            wsysWriter.Flush();

            for (int sci = 0; sci < sceneProjects.Length; sci++)
            {
                util.padTo(wsysWriter, 32);
                var scnData = sceneProjects[sci];
                scnePointers[sci] = (int)wsysWriter.BaseStream.Position;
                wsysWriter.Write(0x53434E45); // SCNE
                wsysWriter.Write(0); // 0?
                var cdfPosAnch = wsysWriter.BaseStream.Position;
                wsysWriter.Write(0); // CDF Pointer
                var cexPosAnch = wsysWriter.BaseStream.Position;
                wsysWriter.Write(0); // CEX pointer
                var cstPosAnch = wsysWriter.BaseStream.Position;
                wsysWriter.Write(0); // CST pointer
                for (int i = 0; i < 0xE; i++)
                    wsysWriter.Write(0); // Padding?
                var cdfPointers = new int[scnData.waves.Length];
                for (int i = 0; i < scnData.waves.Length; i++)
                {
                    wsysWriter.Write(0xCCCCCCCC);
                    wsysWriter.Write(0xFFFFFFFF);
                    cdfPointers[i] = (int)wsysWriter.BaseStream.Position;
                    wsysWriter.Write((short)sci);
                    wsysWriter.Write((short)scnData.waves[i]);
                    for (int b = 0; b < 0xB; b++)
                        wsysWriter.Write(0); // Padding?
                }
                
                util.padTo(wsysWriter, 32);
                var anch = wsysWriter.BaseStream.Position;
                wsysWriter.BaseStream.Position = cdfPosAnch;
                wsysWriter.Write((int)anch);
                wsysWriter.BaseStream.Position = anch;
                wsysWriter.Write(0x432D4446);
                wsysWriter.Write(cdfPointers.Length);
                for (int q = 0; q < cdfPointers.Length; q++)
                {
                    wsysWriter.Write(cdfPointers[q]);
                }

                util.padTo(wsysWriter, 32);
                anch = wsysWriter.BaseStream.Position;
                wsysWriter.BaseStream.Position = cexPosAnch;
                wsysWriter.Write((int)anch);
                wsysWriter.BaseStream.Position = anch;
                wsysWriter.Write(0x432D4558);

                util.padTo(wsysWriter, 32);
                anch = wsysWriter.BaseStream.Position;
                wsysWriter.BaseStream.Position = cstPosAnch;
                wsysWriter.Write((int)anch);
                wsysWriter.BaseStream.Position = anch;
                wsysWriter.Write(0x432D5354);
            }

         
          
            util.padTo(wsysWriter, 32);
            var anch2 = wsysWriter.BaseStream.Position;
            wsysWriter.BaseStream.Position = 0x14;
            wsysWriter.Write((int)anch2);
            wsysWriter.BaseStream.Position = anch2;
            wsysWriter.Write(0x57424354); // WBCT
            wsysWriter.Write(0xFFFFFFFF);
            wsysWriter.Write(sceneCount);
            for (int i = 0; i < scnePointers.Length; i++)
                wsysWriter.Write(scnePointers[i]);
            util.padTo(wsysWriter, 32);

            anch2 = wsysWriter.BaseStream.Position;
            wsysWriter.BaseStream.Position = 0x10;
            wsysWriter.Write((int)anch2);
            wsysWriter.BaseStream.Position = 0x0c;
            wsysWriter.Write(totalWaves);
            wsysWriter.BaseStream.Position = anch2;
            wsysWriter.Write(0x57494E46); // WINF
            wsysWriter.Write(sceneCount);
            for (int i = 0; i < wgPointers.Length; i++)
                wsysWriter.Write(wgPointers[i]);
            util.padTo(wsysWriter, 32);
            var size = wsysWriter.BaseStream.Position;
            wsysWriter.BaseStream.Position = 0x4;
            wsysWriter.Write((int)size);

            wsysWriter.Flush();
        }
    }
}
